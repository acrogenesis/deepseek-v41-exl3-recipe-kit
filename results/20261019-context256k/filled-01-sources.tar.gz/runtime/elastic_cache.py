"""Explicit quiescent expert-cache resize between prefill and generation.

This first implementation writes back GPU-only bytes and drops all GPU entries.
It trades transition latency for simple, auditable ownership; no weights change.
"""
import gc
import time

import torch

from .cache import CacheBusy
from .vendor.expert_store import ALIGN, Regions


def resize(cache, capacity_bytes):
    with cache.lock:
        if cache.closed:
            raise RuntimeError('Cache is closed')
        if cache.arena is not None and cache.arena.numel() == capacity_bytes:
            return None
    layers = sorted(cache.regions)
    if capacity_bytes <= 0 or capacity_bytes % ALIGN:
        raise ValueError('Capacity must be positive and aligned')
    per = capacity_bytes // (len(layers) * ALIGN) * ALIGN
    quotas = {layer: per for layer in layers}
    quotas[layers[-1]] += capacity_bytes - sum(quotas.values())
    for layer, size in quotas.items():
        largest = max(r['bytes'] for k, r in cache.store.records.items()
                      if int(k.split(':')[0]) == layer)
        if size < largest * (6 if cache.native_dispatch is not None else 1):
            raise ValueError('Resized quota cannot hold the required selected experts')
    gpu_only = getattr(cache.store, 'gpu_only_limit', None)
    if gpu_only is not None and capacity_bytes > cache.store.capacity + gpu_only:
        raise ValueError('RAM and GPU-only budgets cannot back the resized cache')
    with torch.cuda.device(cache.device), cache.lock:
        if cache.closed:
            raise RuntimeError('Cache is closed')
        if any(entry.users for entry in cache.entries.values()):
            raise CacheBusy('Cannot resize while a consumer holds a lease')
        before = cache.arena.numel()
        if before == capacity_bytes:
            return None
        started = time.perf_counter()
        resident_before = cache.resident_bytes
        if cache.shared_stream is not None:
            cache.shared_stream.synchronize()
        # clear() waits for each entry's readers and writes GPU-only records back.
        cache.clear()
        cache.copy_stream.synchronize()
        if cache.writeback_stream is not None:
            cache.writeback_stream.synchronize()
        torch.cuda.current_stream(cache.device).synchronize()
        cache.arena = None
        gc.collect()
        torch.cuda.empty_cache()
        # Allocation failure is fatal to this run; close() remains safe. Never
        # keep stale projections pointing into the released allocation.
        cache.arena = torch.empty(capacity_bytes, dtype=torch.uint8, device=cache.device)
        base = 0
        regions = {}
        for layer in layers:
            regions[layer] = Regions(quotas[layer], base)
            base += quotas[layer]
        cache.regions = regions
        cache.stats['resizes'] = cache.stats.get('resizes', 0) + 1
        assert not cache.entries and not cache.slot_projections and cache.resident_bytes == 0
        return dict(from_bytes=before, to_bytes=capacity_bytes,
                    evicted_gpu_bytes=resident_before, seconds=time.perf_counter() - started)
