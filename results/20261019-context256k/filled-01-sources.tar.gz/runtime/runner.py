"""GPU entry point; imports CUDA code only after an explicit execution flag."""
import argparse
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
import os
import inspect
from pathlib import Path
import statistics
import time

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["smoke", "bench"])
    parser.add_argument("--allow-gpu", action="store_true")
    parser.add_argument("--gpu-cache-gib", type=int, choices=range(1, 25))
    parser.add_argument("--ram-cache-gib", type=int, choices=range(16, 85))
    parser.add_argument("--pinned-ram", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--grouped-dispatch", action="store_true", help="Experimental grouped K2/K3 expert GEMV")
    parser.add_argument("--hc-graphs", action="store_true")
    parser.add_argument("--trace-routes", action="store_true")
    parser.add_argument("--gpu-policy", choices=('lru', 'lfu'), default='lru')
    parser.add_argument("--victim-cache", action="store_true")
    parser.add_argument("--gpu-only-gib", type=int, choices=range(1, 25))
    parser.add_argument("--fast-guard", action="store_true")
    parser.add_argument("--fused-reduce", action="store_true")
    parser.add_argument("--overlap-loads", action="store_true")
    parser.add_argument("--overlap-shared", action="store_true")
    parser.add_argument("--engram-cache-rows", type=int, choices=(0, 16384, 65536), default=0)
    parser.add_argument("--context-tokens", type=int, help="Opt-in total KV capacity, including generated tokens")
    parser.add_argument("--prefill-chunk-tokens", type=int, help="Opt-in prefill chunk size, a multiple of 256")
    parser.add_argument("--fused-indexer", action="store_true", help="Experimental bounded-workspace DSV4.1 indexer")
    parser.add_argument("--prefill-gpu-cache-gib", type=int, choices=range(4, 25),
        help="Experimental smaller expert cache during prefill; restored before first generated token")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--fixture", type=Path, default=ROOT / 'fixtures/paired-gguf.json')
    args = parser.parse_args()
    if args.gpu_only_gib is not None and not args.victim_cache:
        parser.error('--gpu-only-gib requires --victim-cache')
    if not args.allow_gpu:
        raise SystemExit("GPU work is on hold. Run scripts/run.sh only after the GPU is free.")
    from scripts.preflight import check
    report = check()
    if not report["ready_for_gpu_validation"]:
        raise SystemExit(json.dumps(report, indent=2))
    profile = json.loads((ROOT / "profiles/5090.json").read_text())
    if args.context_tokens is not None:
        if args.context_tokens < 256 or args.context_tokens > 1048576 or args.context_tokens % 256:
            parser.error('--context-tokens must be a multiple of 256 between 256 and 1048576')
        profile['context_tokens'] = args.context_tokens
    if args.prefill_chunk_tokens is not None:
        profile['prefill_chunk_tokens'] = args.prefill_chunk_tokens
    if args.context_tokens is not None or args.prefill_chunk_tokens is not None:
        profile['status'] = 'experimental context or prefill override; consult this run for validation'
    # Native prefill rounds its end down to a complete 256-token page.
    if profile["prefill_chunk_tokens"] < 256 or profile["prefill_chunk_tokens"] % 256:
        raise ValueError("Prefill chunks must be positive multiples of the native 256-token page")
    for name in ("EXL3_ATS_MMAP", "EXL3_ENGRAM_ATS", "EXL3_MOE_CPU_SPLIT", "EXL3_MOE_CPU_OFFLOAD"):
        os.environ[name] = "0"
    # Keep the first validation on the ordinary EXL3 arithmetic path.
    os.environ["EXL3_INT8_GEMV"] = "0"
    import torch
    from exllamav3 import Config, Tokenizer
    from exllamav3.cache.cache import Cache
    from exllamav3.generator import Generator, Job
    from exllamav3.generator.sampler import GreedySampler
    from .indexed_store import inventory, IndexedExpertStore
    if args.victim_cache:
        from .victim_store import VictimExpertStore as IndexedExpertStore
    from .cache import ExpertCache
    from .native_adapter import attach_engram, build_model
    from .memory_budget import guard_memory
    if args.gpu_cache_gib is not None:
        profile["gpu_expert_cache_bytes"] = args.gpu_cache_gib * 2**30
    if args.ram_cache_gib is not None:
        profile["ram_expert_cache_bytes"] = args.ram_cache_gib * 2**30
    if args.pinned_ram is not None:
        profile['pinned_ram'] = args.pinned_ram
    guard_memory(profile["host_reserve_bytes"])
    if torch.cuda.get_device_capability(0) != (12, 0):
        raise RuntimeError("This build/profile targets the SM120 RTX 5090")
    records, inv = inventory(ROOT)
    store_options = {'gpu_only_limit_bytes': args.gpu_only_gib * 2**30} if args.gpu_only_gib is not None else {}
    store = IndexedExpertStore(ROOT / "work/models/exl3", records, profile["ram_expert_cache_bytes"],
        reserve_bytes=profile["host_reserve_bytes"], pinned=profile.get('pinned_ram', False), **store_options)
    decode_capacity = profile['gpu_expert_cache_bytes']
    capacity = args.prefill_gpu_cache_gib * 2**30 if args.prefill_gpu_cache_gib is not None else decode_capacity
    if capacity > decode_capacity:
        parser.error('--prefill-gpu-cache-gib must not exceed the decode GPU cache')
    per_layer = capacity // (40 * 4096) * 4096
    quotas = {l: per_layer for l in range(40)}
    quotas[39] += capacity - sum(quotas.values())
    experts = ExpertCache(store, capacity, layer_quotas=quotas, reserve_bytes=profile["host_reserve_bytes"],
        grouped_dispatch=args.grouped_dispatch, route_trace=args.trace_routes, policy=args.gpu_policy,
        fast_guard=args.fast_guard, fused_reduce=args.fused_reduce, overlap_loads=args.overlap_loads,
        overlap_shared=args.overlap_shared)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = args.output or ROOT / "results" / f"{stamp}-{args.mode}.json"
    output.resolve().relative_to((ROOT / "results").resolve())
    if output.exists():
        raise FileExistsError(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    result = {"status": "loading", "profile": profile, "inventory": inv, "runs": [],
        "runtime_lock": json.loads((ROOT / "runtime.lock.json").read_text()),
        "gpu": torch.cuda.get_device_name(0), "torch": torch.__version__, "cuda": torch.version.cuda,
        "metric": "Streamed output tokens after first token / elapsed time after first token; fresh KV state each request"}
    result['runtime_sources'] = {}
    result['runtime_sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in (ROOT / 'runtime').iterdir() if p.suffix in ('.py', '.cpp', '.cu', '.h')}
    result['grouped_dispatch'] = args.grouped_dispatch
    result['hc_graphs'] = args.hc_graphs
    result['gpu_policy'] = args.gpu_policy
    result['victim_cache'] = args.victim_cache
    result['gpu_only_limit_gib'] = args.gpu_only_gib
    result['fast_guard'] = args.fast_guard
    result['fused_reduce'] = args.fused_reduce
    result['overlap_loads'] = args.overlap_loads
    result['overlap_shared'] = args.overlap_shared
    result['fused_indexer'] = args.fused_indexer
    result['prefill_gpu_cache_gib'] = args.prefill_gpu_cache_gib
    result['engram_cache_rows'] = args.engram_cache_rows
    result['runtime_source_sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted((ROOT/'runtime').iterdir()) if p.suffix in ('.py', '.cpp', '.cu', '.h')}
    if args.grouped_dispatch:
        result['grouped_source_sha256'] = {name: hashlib.sha256((ROOT/'runtime'/name).read_bytes()).hexdigest()
            for name in ('native_dispatch.cpp', 'native_dispatch.py', 'grouped_dispatch.cu', 'grouped_dispatch.h', 'hc_graphs.py')}
    for cls in (ExpertCache, IndexedExpertStore):
        path = Path(inspect.getfile(cls))
        result['runtime_sources'][cls.__name__] = {'path': str(path.relative_to(ROOT)),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    tune_path = os.environ.get('EXLLAMAV3_TUNE_CACHE')
    result['tune_cache_path'] = tune_path
    result['tune_cache_sha256_before'] = hashlib.sha256(Path(tune_path).read_bytes()).hexdigest() if tune_path and Path(tune_path).exists() else None

    def save():
        tmp = output.with_suffix(".tmp")
        tmp.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
        tmp.replace(output)

    model = None
    try:
        save()
        config = Config.from_directory(str(ROOT / "work/models/exl3"))
        config.infer_params.no_reconstruct = True
        attach_engram(config, ROOT / "work/models/engram")
        model = build_model(config, experts)
        if args.fused_indexer:
            from .long_context import configure as configure_indexer
            configure_indexer(model)
        kv = Cache(model, max_num_tokens=profile["context_tokens"], max_batch_size=1)
        result['kv_pool_bytes'] = sum(layer.storage_size() for layer in kv.layers.values())
        started = time.perf_counter()
        model.load("cuda:0", progressbar=False)
        if args.hc_graphs:
            from .hc_graphs import configure
            configure(model, True)
        from .engram_cache import configure as configure_rows
        row_cache = configure_rows(model, args.engram_cache_rows)
        result["load_seconds"] = time.perf_counter() - started
        free, total = torch.cuda.mem_get_info()
        result["memory_after_load"] = {"device_free_bytes": free, "device_total_bytes": total,
            "torch_allocated_bytes": torch.cuda.memory_allocated(), "torch_reserved_bytes": torch.cuda.memory_reserved()}
        tokenizer = Tokenizer.from_config(config)
        fixture_path = args.fixture
        fixture = json.loads(fixture_path.read_text())
        if fixture["context"] != profile["context_tokens"]:
            raise RuntimeError("Context differs from paired GGUF fixture")
        result["fixture_sha256"] = hashlib.sha256(fixture_path.read_bytes()).hexdigest()
        for case in fixture["checks"] + fixture["speed"]:
            actual = tokenizer.encode(case["rendered_prompt"], add_bos=False, encode_special_tokens=True).flatten().tolist()
            if actual != case["input_ids"]:
                raise RuntimeError(f"Tokenizer differs from paired fixture: {case['id']}")

        def run(case, phase, cap):
            # A new generator creates a fresh page table and resets recurrent state.
            generator = Generator(model=model, cache=kv, tokenizer=tokenizer,
                max_batch_size=1, max_chunk_size=profile["prefill_chunk_tokens"], recurrent_cache_size=512 * 2**20)
            ids = torch.tensor([case["input_ids"]], dtype=torch.long)
            job = Job(input_ids=ids, max_new_tokens=cap, sampler=GreedySampler(),
                stop_conditions=config.eos_token_id_list)
            generator.enqueue(job)
            tokens, chunks, events = [], [], []
            start = time.perf_counter()
            transitions = []
            if args.prefill_gpu_cache_gib is not None:
                from .elastic_cache import resize
                def transition(target, stage):
                    changed = resize(experts, target)
                    if changed is not None:
                        transitions.append(dict(changed, stage=stage))
                transition(capacity, 'prefill')
                original_iterate_gen = generator.iterate_gen
                def iterate_gen(*a, **kw):
                    if all(seq.prefill_complete for seq in job.sequences):
                        transition(decode_capacity, 'decode')
                    return original_iterate_gen(*a, **kw)
                generator.iterate_gen = iterate_gen
            first = last = None
            first_count = 0
            first_counters = None
            previous_progress = None
            last_progress_at = time.monotonic()
            last_report_at = time.monotonic()
            while generator.num_remaining_jobs():
                for event in generator.iterate():
                    if event.get("stage") == "error":
                        raise RuntimeError(str(event))
                    if event.get("stage") != "streaming":
                        continue
                    if event.get("text"):
                        chunks.append(event["text"])
                    emitted = event.get("token_ids")
                    if emitted is None or not emitted.numel():
                        continue
                    torch.cuda.synchronize()
                    now = time.perf_counter() - start
                    if first is None:
                        first, first_count = now, emitted.numel()
                        first_counters = dict(ram_cache=dict(store.stats), gpu_cache=dict(experts.stats))
                    last = now
                    token_ids = emitted.flatten().tolist()
                    tokens.extend(token_ids)
                    events.append({"seconds": now, "tokens": token_ids})
                progress = (tuple(s.kv_position for s in job.sequences), len(tokens))
                if progress != previous_progress:
                    previous_progress, last_progress_at = progress, time.monotonic()
                elif time.monotonic() - last_progress_at > 120:
                    raise RuntimeError("Generation made no progress for 120 seconds")
                if time.monotonic() - last_report_at >= 30:
                    result['progress'] = dict(id=case['id'], phase=phase,
                        kv_positions=list(progress[0]), output_tokens=len(tokens),
                        seconds=time.perf_counter() - start)
                    save()
                    print(json.dumps(result['progress']), flush=True)
                    last_report_at = time.monotonic()
            duration = time.perf_counter() - start
            rate = (len(tokens) - first_count) / (last - first) if first is not None and last > first else None
            row = {"id": case["id"], "phase": phase, "input_tokens": len(case["input_ids"]),
                "output_tokens": len(tokens), "token_ids": tokens, "text": "".join(chunks),
                "ttft_seconds": first, "seconds": duration, "decode_tok_s": rate, "events": events,
                "ram_cache": dict(store.stats), "gpu_cache": dict(experts.stats),
                "gpu_peak_allocated_bytes": torch.cuda.max_memory_allocated()}
            row['final_kv_positions'] = [seq.kv_position for seq in job.sequences]
            if tokens and any(position < len(case['input_ids']) for position in row['final_kv_positions']):
                raise RuntimeError('Generation finished without consuming the complete prompt')
            row["gpu_peak_reserved_bytes"] = torch.cuda.max_memory_reserved()
            row['expert_cache_transitions'] = transitions
            row['decode_cache_delta'] = ({name: {key: value - first_counters[name].get(key, 0)
                for key, value in counters.items()} for name, counters in
                (('ram_cache', store.stats), ('gpu_cache', experts.stats))} if first_counters is not None else None)
            if row_cache is not None:
                row['engram_cache'] = dict(row_cache.stats, resident_rows=len(row_cache.rows),
                    payload_bytes=row_cache.payload_bytes)
            row["device_free_bytes_after_request"] = torch.cuda.mem_get_info()[0]
            from .memory_budget import available_memory, cgroup_path
            group = cgroup_path()
            row['host_available_bytes'] = available_memory()
            row['cgroup_memory_current'] = int((group / 'memory.current').read_text())
            row['cgroup_memory_peak'] = int((group / 'memory.peak').read_text())
            row['cgroup_swap_current'] = int((group / 'memory.swap.current').read_text())
            if "expected" in case:
                actual = row["text"].strip()
                expected = case["expected"]
                if not isinstance(expected, str):
                    try:
                        actual = json.loads(actual)
                    except ValueError:
                        pass
                passed = actual == expected
                if case["id"] in ("multiply", "remaining", "percentage", "python"):
                    try:
                        passed = Decimal(actual) == Decimal(expected)
                    except (InvalidOperation, TypeError):
                        passed = False
                row.update(passed=passed, expected=expected)
            if 'expected_registry' in case:
                answer = row['text'].lstrip()
                format_ = 'plain_json'
                if answer.startswith('```json\n') or answer.startswith('```\n'):
                    answer = answer.split('\n', 1)[1]
                    format_ = 'fenced_json'
                try:
                    registry, _ = json.JSONDecoder().raw_decode(answer.lstrip())
                except ValueError:
                    registry = None
                row['retrieval'] = dict(passed=registry == case['expected_registry'],
                    expected=case['expected_registry'], actual=registry,
                    marker_token_offsets=case['marker_token_offsets'], format=format_)
            if experts.route_trace is not None:
                row['route_trace'] = experts.route_trace
                experts.route_trace = []
            result["runs"].append(row)
            save()
            print(json.dumps({k: row[k] for k in ("id", "phase", "decode_tok_s", "ttft_seconds", "text")}), flush=True)

        result["status"] = "running"
        save()
        with torch.inference_mode():
            if args.mode == "smoke":
                run(fixture["checks"][3], "smoke", 16)
                if not result["runs"][-1]["passed"]:
                    raise RuntimeError("First completion failed the exact extraction check")
            else:
                for case in fixture["checks"]:
                    run(case, "check", fixture.get('check_output_cap', 64))
                for phase in ("fresh", "repeat"):
                    for case in fixture["speed"]:
                        run(case, phase, fixture["output_cap"])
                for phase in ("fresh", "repeat"):
                    rates = [r["decode_tok_s"] for r in result["runs"] if r["phase"] == phase]
                    if not rates or any(r is None or r <= 0 for r in rates):
                        raise RuntimeError("Missing usable benchmark measurements")
                    result[phase + "_median_tok_s"] = statistics.median(rates)
        result["status"] = "complete"
    except BaseException as exc:
        result.update(status="failed", error=repr(exc))
        raise
    finally:
        result['tune_cache_sha256_after'] = hashlib.sha256(Path(tune_path).read_bytes()).hexdigest() if tune_path and Path(tune_path).exists() else None
        save()
        if model is not None:
            model.unload()
        experts.close()
        store.close()
        print(f"Saved {output}", flush=True)


if __name__ == "__main__":
    main()
